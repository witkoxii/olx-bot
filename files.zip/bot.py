import discord
from discord.ext import commands, tasks
import aiohttp
import asyncio
import json
import os
import re
from datetime import datetime
from bs4 import BeautifulSoup

# ── Konfiguracja ──────────────────────────────────────────────────────────────
CONFIG_FILE = "config.json"
SEEN_FILE = "seen_listings.json"

intents = discord.Intents.default()
intents.message_content = True
bot = commands.Bot(command_prefix="!", intents=intents)

# ── Pomocnicze funkcje plików ─────────────────────────────────────────────────

def load_json(path, default):
    if os.path.exists(path):
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    return default

def save_json(path, data):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

# ── Stan globalny ─────────────────────────────────────────────────────────────

config = load_json(CONFIG_FILE, {
    "channel_id": None,
    "city": "warszawa",
    "max_price": None,
    "min_price": None,
    "models": [],          # np. ["iPhone 13", "iPhone 14"]
    "interval_minutes": 5,
    "sources": ["olx", "allegro"],
})

seen = load_json(SEEN_FILE, [])

# ── Scrapery ──────────────────────────────────────────────────────────────────

HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/124.0 Safari/537.36"
    )
}

async def scrape_olx(session: aiohttp.ClientSession) -> list[dict]:
    listings = []
    city = config.get("city", "warszawa").lower()

    query = "iphone"
    models = config.get("models", [])
    if models:
        query = models[0]  # szukaj pierwszego modelu; pętla niżej

    search_terms = models if models else ["iphone"]

    for term in search_terms:
        url = (
            f"https://www.olx.pl/elektronika/telefony/apple-iphone/"
            f"q-{term.replace(' ', '-')}/"
        )
        if city and city != "polska":
            url = (
                f"https://www.olx.pl/elektronika/telefony/apple-iphone/"
                f"{city}/q-{term.replace(' ', '-')}/"
            )

        params = {}
        if config.get("max_price"):
            params["search[filter_float_price:to]"] = config["max_price"]
        if config.get("min_price"):
            params["search[filter_float_price:from]"] = config["min_price"]

        try:
            async with session.get(url, headers=HEADERS, params=params, timeout=aiohttp.ClientTimeout(total=15)) as resp:
                if resp.status != 200:
                    continue
                html = await resp.text()
        except Exception:
            continue

        soup = BeautifulSoup(html, "html.parser")

        # OLX structure (może się zmienić)
        cards = soup.select("div[data-cy='l-card']")
        for card in cards:
            try:
                title_el = card.select_one("h6")
                title = title_el.get_text(strip=True) if title_el else "—"

                price_el = card.select_one("[data-testid='ad-price']")
                price = price_el.get_text(strip=True) if price_el else "—"

                link_el = card.select_one("a[href]")
                link = link_el["href"] if link_el else ""
                if link and not link.startswith("http"):
                    link = "https://www.olx.pl" + link

                location_el = card.select_one("[data-testid='location-date']")
                location = location_el.get_text(strip=True) if location_el else "—"

                img_el = card.select_one("img")
                image = img_el.get("src", "") if img_el else ""

                listing_id = f"olx_{link.split('ID')[-1].split('.')[0]}" if "ID" in link else f"olx_{hash(link)}"

                listings.append({
                    "id": listing_id,
                    "title": title,
                    "price": price,
                    "location": location,
                    "link": link,
                    "image": image,
                    "source": "OLX",
                    "battery": extract_battery(title),
                    "condition": extract_condition(title),
                })
            except Exception:
                continue

    return listings


async def scrape_allegro(session: aiohttp.ClientSession) -> list[dict]:
    listings = []
    search_terms = config.get("models", ["iphone"])
    if not search_terms:
        search_terms = ["iphone"]

    for term in search_terms:
        url = "https://allegro.pl/listing"
        params = {
            "string": term,
            "order": "n",
            "bmatch": "baseline-product-cl-eyesa2-engag-dict45-ele-1-2-0324",
            "category.id": "165",  # Telefony > Apple iPhone
        }
        if config.get("max_price"):
            params["price_to"] = config["max_price"]
        if config.get("min_price"):
            params["price_from"] = config["min_price"]

        try:
            async with session.get(url, headers=HEADERS, params=params, timeout=aiohttp.ClientTimeout(total=15)) as resp:
                if resp.status != 200:
                    continue
                html = await resp.text()
        except Exception:
            continue

        soup = BeautifulSoup(html, "html.parser")

        articles = soup.select("article")
        for art in articles:
            try:
                title_el = art.select_one("h2")
                title = title_el.get_text(strip=True) if title_el else "—"

                if "iphone" not in title.lower():
                    continue

                price_el = art.select_one("span[aria-label*='zł'], span[aria-label*='PLN'], meta[itemprop='price']")
                price = "—"
                if price_el:
                    if price_el.name == "meta":
                        price = price_el.get("content", "—") + " zł"
                    else:
                        price = price_el.get_text(strip=True)

                link_el = art.select_one("a[href]")
                link = link_el["href"] if link_el else ""
                if link and not link.startswith("http"):
                    link = "https://allegro.pl" + link

                img_el = art.select_one("img")
                image = img_el.get("src", "") if img_el else ""

                listing_id = f"allegro_{hash(link)}"

                listings.append({
                    "id": listing_id,
                    "title": title,
                    "price": price,
                    "location": "Allegro",
                    "link": link,
                    "image": image,
                    "source": "Allegro",
                    "battery": extract_battery(title),
                    "condition": extract_condition(title),
                })
            except Exception:
                continue

    return listings


def extract_battery(text: str) -> str:
    """Wyciąga pojemność baterii z tytułu ogłoszenia."""
    match = re.search(r"bater[a-ząęóśłżźćń]*\s*[:\-]?\s*(\d{1,3})\s*%", text, re.IGNORECASE)
    if match:
        return match.group(1) + "%"
    match = re.search(r"(\d{2,3})\s*%\s*bater", text, re.IGNORECASE)
    if match:
        return match.group(1) + "%"
    return "—"


def extract_condition(text: str) -> str:
    """Wyciąga stan urządzenia z tytułu."""
    text_lower = text.lower()
    if any(w in text_lower for w in ["nowy", "nowe", "new", "zafoliowany"]):
        return "🟢 Nowy"
    if any(w in text_lower for w in ["jak nowy", "idealny", "bdb", "bardzo dobry"]):
        return "🟡 Jak nowy"
    if any(w in text_lower for w in ["dobry", "db", "używany", "uzywany"]):
        return "🟠 Dobry"
    if any(w in text_lower for w in ["uszkodzon", "zepsuty", "do naprawy", "parts"]):
        return "🔴 Uszkodzony"
    return "⚪ Nieznany"

# ── Budowanie embedu Discord ───────────────────────────────────────────────────

def build_embed(listing: dict) -> discord.Embed:
    color = {
        "OLX": 0x00A651,
        "Allegro": 0xFF5A00,
    }.get(listing["source"], 0x5865F2)

    embed = discord.Embed(
        title=listing["title"][:256],
        url=listing["link"],
        color=color,
        timestamp=datetime.utcnow(),
    )
    embed.add_field(name="💰 Cena", value=listing["price"], inline=True)
    embed.add_field(name="📍 Lokalizacja", value=listing["location"], inline=True)
    embed.add_field(name="🔋 Bateria", value=listing["battery"], inline=True)
    embed.add_field(name="📦 Stan", value=listing["condition"], inline=True)
    embed.add_field(name="🌐 Źródło", value=listing["source"], inline=True)

    if listing.get("image"):
        embed.set_thumbnail(url=listing["image"])

    embed.set_footer(text="iPhone Hunter Bot")
    return embed

# ── Task główny ────────────────────────────────────────────────────────────────

@tasks.loop(minutes=1)  # dokładny interwał ustawiany dynamicznie poniżej
async def check_listings():
    global seen
    channel_id = config.get("channel_id")
    if not channel_id:
        return

    channel = bot.get_channel(int(channel_id))
    if not channel:
        return

    async with aiohttp.ClientSession() as session:
        all_listings = []

        sources = config.get("sources", ["olx", "allegro"])
        if "olx" in sources:
            all_listings += await scrape_olx(session)
        if "allegro" in sources:
            all_listings += await scrape_allegro(session)

    new_found = []
    for listing in all_listings:
        if listing["id"] not in seen:
            seen.append(listing["id"])
            new_found.append(listing)

    # Ogranicz rozmiar seen do 2000 wpisów
    if len(seen) > 2000:
        seen = seen[-2000:]
    save_json(SEEN_FILE, seen)

    for listing in new_found:
        embed = build_embed(listing)
        try:
            await channel.send(embed=embed)
            await asyncio.sleep(1)
        except Exception as e:
            print(f"Błąd wysyłania: {e}")


@check_listings.before_loop
async def before_check():
    await bot.wait_until_ready()


def restart_task():
    """Restartuje task z nowym interwałem."""
    check_listings.cancel()
    interval = max(1, config.get("interval_minutes", 5))
    check_listings.change_interval(minutes=interval)
    check_listings.start()

# ── Komendy bota ──────────────────────────────────────────────────────────────

@bot.event
async def on_ready():
    print(f"✅ Zalogowano jako {bot.user} ({bot.user.id})")
    restart_task()


@bot.command(name="setchannel")
@commands.has_permissions(manage_channels=True)
async def set_channel(ctx, channel: discord.TextChannel = None):
    """Ustawia kanał do powiadomień. Użycie: !setchannel #kanał"""
    ch = channel or ctx.channel
    config["channel_id"] = ch.id
    save_json(CONFIG_FILE, config)
    await ctx.send(f"✅ Kanał powiadomień ustawiony na {ch.mention}")


@bot.command(name="setcity")
async def set_city(ctx, *, city: str):
    """Ustawia miasto wyszukiwania. Użycie: !setcity warszawa | !setcity polska"""
    config["city"] = city.lower().strip()
    save_json(CONFIG_FILE, config)
    await ctx.send(f"✅ Miasto ustawione na: **{city}**")


@bot.command(name="setprice")
async def set_price(ctx, min_price: int = None, max_price: int = None):
    """Ustawia zakres cen. Użycie: !setprice 500 3000"""
    config["min_price"] = min_price
    config["max_price"] = max_price
    save_json(CONFIG_FILE, config)
    parts = []
    if min_price is not None:
        parts.append(f"od **{min_price} zł**")
    if max_price is not None:
        parts.append(f"do **{max_price} zł**")
    msg = "✅ Zakres cen: " + (", ".join(parts) if parts else "bez limitu")
    await ctx.send(msg)


@bot.command(name="addmodel")
async def add_model(ctx, *, model: str):
    """Dodaje model iPhone do wyszukiwania. Użycie: !addmodel iPhone 13 Pro"""
    models = config.get("models", [])
    if model not in models:
        models.append(model)
    config["models"] = models
    save_json(CONFIG_FILE, config)
    await ctx.send(f"✅ Dodano model: **{model}**\nAktywne: {', '.join(models)}")


@bot.command(name="removemodel")
async def remove_model(ctx, *, model: str):
    """Usuwa model z wyszukiwania. Użycie: !removemodel iPhone 13 Pro"""
    models = config.get("models", [])
    if model in models:
        models.remove(model)
        config["models"] = models
        save_json(CONFIG_FILE, config)
        await ctx.send(f"✅ Usunięto model: **{model}**")
    else:
        await ctx.send(f"⚠️ Nie znaleziono modelu: **{model}**")


@bot.command(name="setinterval")
async def set_interval(ctx, minutes: int):
    """Ustawia interwał sprawdzania (minuty). Użycie: !setinterval 10"""
    if minutes < 1:
        await ctx.send("⚠️ Minimalny interwał to 1 minuta.")
        return
    config["interval_minutes"] = minutes
    save_json(CONFIG_FILE, config)
    restart_task()
    await ctx.send(f"✅ Interwał sprawdzania: **{minutes} minut**")


@bot.command(name="setsources")
async def set_sources(ctx, *sources):
    """Ustawia źródła ogłoszeń. Użycie: !setsources olx allegro"""
    valid = [s.lower() for s in sources if s.lower() in ("olx", "allegro")]
    if not valid:
        await ctx.send("⚠️ Podaj przynajmniej jedno źródło: `olx`, `allegro`")
        return
    config["sources"] = valid
    save_json(CONFIG_FILE, config)
    await ctx.send(f"✅ Aktywne źródła: {', '.join(valid).upper()}")


@bot.command(name="status")
async def status(ctx):
    """Pokazuje aktualną konfigurację bota."""
    models = config.get("models") or ["wszystkie iPhone'y"]
    sources = config.get("sources", ["olx", "allegro"])
    min_p = config.get("min_price") or "brak"
    max_p = config.get("max_price") or "brak"
    city = config.get("city", "polska")
    interval = config.get("interval_minutes", 5)
    channel_id = config.get("channel_id")
    ch_mention = f"<#{channel_id}>" if channel_id else "nie ustawiony"

    embed = discord.Embed(title="📱 iPhone Hunter — Status", color=0x5865F2)
    embed.add_field(name="📢 Kanał", value=ch_mention, inline=False)
    embed.add_field(name="🔍 Modele", value=", ".join(models), inline=False)
    embed.add_field(name="📍 Zasięg / Miasto", value=city.capitalize(), inline=True)
    embed.add_field(name="💰 Cena min", value=f"{min_p} zł" if min_p != "brak" else min_p, inline=True)
    embed.add_field(name="💰 Cena max", value=f"{max_p} zł" if max_p != "brak" else max_p, inline=True)
    embed.add_field(name="⏱ Interwał", value=f"{interval} min", inline=True)
    embed.add_field(name="🌐 Źródła", value=", ".join(s.upper() for s in sources), inline=True)
    embed.add_field(name="👁 Widziane ogłoszenia", value=str(len(seen)), inline=True)
    await ctx.send(embed=embed)


@bot.command(name="reset")
@commands.has_permissions(manage_channels=True)
async def reset_seen(ctx):
    """Resetuje listę widzianych ogłoszeń (pokaże wszystkie od nowa)."""
    global seen
    seen = []
    save_json(SEEN_FILE, seen)
    await ctx.send("✅ Lista widzianych ogłoszeń wyczyszczona.")


@bot.command(name="scan")
async def manual_scan(ctx):
    """Ręcznie uruchamia skan ogłoszeń."""
    await ctx.send("🔍 Skatuję ogłoszenia...")
    await check_listings()
    await ctx.send("✅ Skan zakończony.")


@bot.command(name="help_iphone")
async def help_iphone(ctx):
    """Wyświetla pomoc."""
    embed = discord.Embed(
        title="📱 iPhone Hunter — Komendy",
        description="Bot monitoruje OLX i Allegro w poszukiwaniu używanych iPhone'ów.",
        color=0x5865F2,
    )
    cmds = [
        ("!setchannel [#kanał]", "Ustawia kanał powiadomień"),
        ("!setcity <miasto>", "Ustaw miasto lub `polska` dla całego kraju"),
        ("!setprice [min] [max]", "Zakres cen, np. `!setprice 1000 4000`"),
        ("!addmodel <model>", "Dodaj model, np. `!addmodel iPhone 13 Pro`"),
        ("!removemodel <model>", "Usuń model z listy"),
        ("!setinterval <minuty>", "Jak często sprawdzać (min. 1)"),
        ("!setsources <źródła>", "np. `!setsources olx allegro`"),
        ("!status", "Pokaż aktualną konfigurację"),
        ("!scan", "Ręczny skan teraz"),
        ("!reset", "Wyczyść historię (wyświetli wszystkie ponownie)"),
    ]
    for name, desc in cmds:
        embed.add_field(name=f"`{name}`", value=desc, inline=False)
    await ctx.send(embed=embed)


# ── Uruchomienie ───────────────────────────────────────────────────────────────

if __name__ == "__main__":
    TOKEN = os.environ.get("DISCORD_TOKEN")
    if not TOKEN:
        print("❌ Brak zmiennej środowiskowej DISCORD_TOKEN!")
        print("   Ustaw: export DISCORD_TOKEN='twój_token'")
        exit(1)
    bot.run(TOKEN)
